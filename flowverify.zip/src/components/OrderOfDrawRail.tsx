/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ShieldAlert, CheckCircle2, ChevronRight, HelpCircle, ExternalLink } from 'lucide-react';
import { CapColor, ObservedTube } from '../types';

interface OrderOfDrawRailProps {
  lastAcceptedRank: number;
  observedTubes: ObservedTube[];
}

const RAIL_CATEGORIES: {
  id: CapColor;
  name: string;
  rank: number;
  desc: string;
}[] = [
  { id: 'blood_culture', name: '1. Blood Culture', rank: 1, desc: 'Aerobic / Anaerobic bottles' },
  { id: 'light_blue', name: '2. Light Blue', rank: 2, desc: 'Coagulation (Sodium Citrate)' },
  { id: 'red', name: '3. Red', rank: 3, desc: 'Serum Clot Activator' },
  { id: 'gold', name: '4. Gold / SST', rank: 4, desc: 'Gel Separator Tube' },
  { id: 'green', name: '5. Green', rank: 5, desc: 'Heparin (Sodium / Lithium)' },
  { id: 'lavender', name: '6. Lavender', rank: 6, desc: 'Hematology (EDTA)' },
  { id: 'gray', name: '7. Gray', rank: 7, desc: 'Glycolysis (Fluoride Oxalate)' },
];

export default function OrderOfDrawRail({ lastAcceptedRank, observedTubes }: OrderOfDrawRailProps) {
  // Count distinct observed categories
  const observedCount = RAIL_CATEGORIES.filter((cat) =>
    observedTubes.some((t) => t.cap_color === cat.id)
  ).length;

  return (
    <div className="flex flex-col h-full bg-[#121214] border border-[#2D2D2D] rounded p-5 text-[#E2E2E2] space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#2D2D2D] pb-3">
        <div>
          <h3 className="text-xs font-bold uppercase tracking-widest text-[#8E9299]">
            WHO Order of Draw Rail
          </h3>
          <p className="text-xs font-semibold text-[#06B6D4] uppercase tracking-wider mt-1">
            {observedCount} category observed
          </p>
        </div>
        <a
          href="https://www.who.int/publications/i/item/9789241599221"
          target="_blank"
          rel="noopener noreferrer"
          title="WHO Guidelines on Drawing Blood"
          className="text-[#8E9299] hover:text-[#06B6D4] transition-colors p-1 rounded hover:bg-white/5"
        >
          <ExternalLink className="w-4 h-4" />
        </a>
      </div>

      {/* Categories List */}
      <div className="flex-1 space-y-3 overflow-y-auto">
        {RAIL_CATEGORIES.map((cat) => {
          const occurrences = observedTubes.filter((t) => t.cap_color === cat.id);
          const isObserved = occurrences.length > 0;
          const hasValid = occurrences.some((t) => t.valid);
          const hasInvalid = occurrences.some((t) => !t.valid);

          // Allowed check
          const isAllowed = lastAcceptedRank === 0 || cat.rank >= lastAcceptedRank;

          // Status label text
          let statusText = 'Pending draw';
          let statusColor = 'text-[#8E9299]';
          let icon = <ChevronRight className="w-4 h-4 text-gray-600" />;

          if (isObserved) {
            if (hasInvalid) {
              statusText = 'Moved backward';
              statusColor = 'text-[#DC2626] font-semibold';
              icon = <ShieldAlert className="w-4 h-4 text-[#DC2626] animate-pulse" />;
            } else if (hasValid) {
              statusText = 'Observed in order';
              statusColor = 'text-emerald-400 font-medium';
              icon = <CheckCircle2 className="w-4 h-4 text-emerald-400" />;
            }
          } else if (lastAcceptedRank > 0 && cat.rank < lastAcceptedRank) {
            statusText = 'Already passed';
            statusColor = 'text-[#8E9299] line-through';
            icon = <HelpCircle className="w-4 h-4 text-gray-600" />;
          }

          // Background styling for active/allowed state
          const bgStyle = isObserved
            ? hasInvalid
              ? 'bg-[#DC2626]/5 border-[#DC2626]/20'
              : 'bg-emerald-950/10 border-emerald-900/20'
            : isAllowed
            ? 'bg-[#0891B2]/5 border-[#0891B2]/10'
            : 'bg-transparent border-transparent';

          return (
            <div
              key={cat.id}
              className={`p-3 rounded border text-xs flex items-center justify-between transition-all ${bgStyle}`}
            >
              <div className="flex items-center gap-3">
                {/* Visual cap representation */}
                <div
                  className="w-4 h-12 rounded border border-[#2D2D2D] shadow-inner"
                  style={{
                    backgroundColor:
                      cat.id === 'blood_culture' ? '#d97706' :
                      cat.id === 'light_blue' ? '#38bdf8' :
                      cat.id === 'red' ? '#ef4444' :
                      cat.id === 'gold' ? '#f59e0b' :
                      cat.id === 'green' ? '#10b981' :
                      cat.id === 'lavender' ? '#a855f7' :
                      cat.id === 'gray' ? '#6b7280' : '#1e293b'
                  }}
                  title={cat.name}
                />

                <div className="space-y-0.5">
                  <p className="font-semibold text-[#E2E2E2]">{cat.name}</p>
                  <p className="text-[10px] text-[#8E9299] leading-tight">{cat.desc}</p>
                  <p className={`text-[10px] ${statusColor} flex items-center gap-1`}>
                    {statusText}
                  </p>
                </div>
              </div>

              <div className="flex flex-col items-end gap-1.5">
                {icon}
                {isAllowed && (
                  <span className="text-[9px] font-bold tracking-widest uppercase text-[#06B6D4] px-1.5 py-0.5 rounded bg-[#0891B2]/5 border border-[#0891B2]/20 font-sans">
                    Allowed
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer helper */}
      <div className="bg-[#1A1B1E] p-3 rounded border border-[#2D2D2D] text-[10px] text-[#8E9299] leading-normal font-sans">
        <p>
          Before drawing, ensure the patient ID is verified and the tourniquet time is monitored under 60 seconds.
        </p>
      </div>
    </div>
  );
}
