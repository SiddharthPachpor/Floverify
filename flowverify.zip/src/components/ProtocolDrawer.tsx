/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, BookOpen, Cpu, ShieldCheck } from 'lucide-react';
import { WHO_PROTOCOL } from '../lib/protocolEngine';

interface ProtocolDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ProtocolDrawer({ isOpen, onClose }: ProtocolDrawerProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm transition-opacity">
      {/* Click outside to close */}
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative w-full max-w-2xl h-full bg-[#121214] border-l border-[#2D2D2D] shadow-2xl flex flex-col text-[#E2E2E2] z-10 animate-slide-in">
        {/* Header */}
        <div className="p-6 border-b border-[#2D2D2D] flex items-center justify-between bg-[#121214]">
          <div className="flex items-center gap-3">
            <BookOpen className="w-5 h-5 text-[#06B6D4]" />
            <h2 className="text-sm font-bold tracking-widest text-[#E2E2E2] uppercase font-sans">
              WHO Phlebotomy Protocol Engine
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded hover:bg-white/5 text-[#8E9299] hover:text-[#E2E2E2] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-[#0A0A0B]">
          {/* Paradigm box */}
          <div className="p-4 rounded bg-[#0891B2]/5 border border-[#0891B2]/20 space-y-3">
            <div className="flex items-center gap-2 text-[#06B6D4] font-medium">
              <ShieldCheck className="w-5 h-5" />
              <h3 className="uppercase tracking-wider text-xs font-bold">Core Architecture Principle</h3>
            </div>
            <p className="text-sm text-[#06B6D4] font-semibold leading-relaxed font-sans">
              “Gemini classifies. The compiled protocol judges.”
            </p>
            <p className="text-xs text-[#8E9299] leading-relaxed font-sans">
              In FlowVerify, Gemini never decides whether an action is correct. It is strictly limited to vision classification — reporting what is happening (e.g. tourniquet applied, tube colors). Correctness checks, timing rules, and sequence ordering are evaluated deterministically in the client compile engine.
            </p>
          </div>

          {/* Details */}
          <div className="space-y-2">
            <h4 className="text-[10px] font-bold uppercase tracking-widest text-[#8E9299]">
              Official Reference
            </h4>
            <div className="p-4 rounded bg-[#1A1B1E] border border-[#2D2D2D] flex items-start gap-3">
              <Cpu className="w-5 h-5 text-[#8E9299] mt-1" />
              <div className="space-y-1">
                <p className="text-xs font-semibold text-[#E2E2E2]">{WHO_PROTOCOL.source}</p>
                <a
                  href={WHO_PROTOCOL.source_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-[#06B6D4] hover:underline inline-flex items-center gap-1 font-semibold uppercase tracking-wider"
                >
                  View WHO Publication URL →
                </a>
              </div>
            </div>
          </div>

          {/* Pretty print JSON */}
          <div className="space-y-2 flex-1 flex flex-col">
            <h4 className="text-[10px] font-bold uppercase tracking-widest text-[#8E9299]">
              Machine-Readable Artifact Spec (JSON)
            </h4>
            <pre className="flex-1 p-4 rounded bg-[#121214] border border-[#2D2D2D] font-mono text-xs text-[#06B6D4] overflow-auto max-h-[350px] leading-relaxed select-all">
              {JSON.stringify(WHO_PROTOCOL, null, 2)}
            </pre>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#121214] border-t border-[#2D2D2D] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#2D2D2D] hover:bg-[#3D3D3D] border border-[#3D3D3D] rounded text-xs font-bold text-[#E2E2E2] uppercase tracking-widest transition-all"
          >
            Close Specification
          </button>
        </div>
      </div>
    </div>
  );
}
