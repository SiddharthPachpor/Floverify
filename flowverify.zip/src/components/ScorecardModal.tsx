/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, CheckCircle2, AlertTriangle, RefreshCw, Award, BookOpen, Clock } from 'lucide-react';
import { Violation, ObservedTube } from '../types';
import { getFriendlyName } from '../lib/protocolEngine';

interface ScorecardModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRestart: () => void;
  stats: {
    accuracy: number;
    completed: number;
    totalChecks: number;
    exceptionCount: number;
    passed: boolean;
    violations: Violation[];
    observedTubes: ObservedTube[];
    runDuration: number;
  } | null;
}

export default function ScorecardModal({ isOpen, onClose, onRestart, stats }: ScorecardModalProps) {
  if (!isOpen || !stats) return null;

  const {
    accuracy,
    completed,
    totalChecks,
    exceptionCount,
    passed,
    violations,
    observedTubes,
    runDuration,
  } = stats;

  const accuracyPct = Math.round(accuracy * 100);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md">
      <div className="relative w-full max-w-2xl bg-[#121214] border border-[#2D2D2D] rounded shadow-2xl flex flex-col text-[#E2E2E2] max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-[#2D2D2D] flex items-center justify-between bg-[#121214]">
          <div className="flex items-center gap-3">
            <Award className="w-5 h-5 text-[#06B6D4]" />
            <h2 className="text-sm font-bold tracking-widest uppercase">Clinical Performance Scorecard</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded hover:bg-white/5 text-[#8E9299] hover:text-[#E2E2E2] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-[#0A0A0B]">
          {/* Main Grade Box */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className={`p-5 rounded border flex items-center gap-4 ${
              observedTubes.length === 0
                ? 'bg-zinc-950/20 border-zinc-800'
                : passed
                ? 'bg-emerald-950/10 border-emerald-950/20'
                : 'bg-[#DC2626]/5 border-[#DC2626]/20'
            }`}>
              {observedTubes.length === 0 ? (
                <div className="w-12 h-12 rounded-full bg-zinc-900 flex items-center justify-center text-[#8E9299] font-mono text-xl font-bold">
                  Ø
                </div>
              ) : passed ? (
                <CheckCircle2 className="w-12 h-12 text-emerald-400 flex-shrink-0" />
              ) : (
                <AlertTriangle className="w-12 h-12 text-[#DC2626] flex-shrink-0" />
              )}
              <div>
                <p className="text-[10px] text-[#8E9299] uppercase tracking-wider font-semibold">
                  Evaluation Verdict
                </p>
                <h3 className="text-sm font-bold tracking-wider uppercase mt-0.5">
                  {observedTubes.length === 0 ? (
                    <span className="text-zinc-400">Empty Run</span>
                  ) : passed ? (
                    <span className="text-emerald-400">PROTOCOL PASSED</span>
                  ) : (
                    <span className="text-[#DC2626]">NEEDS CLINICAL REVIEW</span>
                  )}
                </h3>
                <p className="text-xs text-[#8E9299] mt-1">
                  {observedTubes.length === 0
                    ? 'No tube insertions were verified.'
                    : passed
                    ? 'All observed draws executed in compliance with WHO order of draw.'
                    : 'Procedural violations detected. Patient sample risks contamination.'}
                </p>
              </div>
            </div>

            {/* Accuracy Score */}
            <div className="p-5 rounded bg-[#121214] border border-[#2D2D2D] flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-[#8E9299] uppercase tracking-wider font-semibold">
                  Clinical Accuracy
                </span>
                <span className="text-xs text-[#06B6D4] font-mono font-bold">
                  {completed} / {totalChecks} draws
                </span>
              </div>
              <div className="flex items-baseline gap-2 mt-2">
                <span className="text-4xl font-extrabold text-[#E2E2E2] font-mono">
                  {observedTubes.length === 0 ? '--' : `${accuracyPct}%`}
                </span>
              </div>
              <div className="w-full bg-[#2D2D2D] h-1.5 rounded mt-3 overflow-hidden">
                <div
                  className={`h-full rounded transition-all duration-500 ${
                    passed ? 'bg-emerald-400' : 'bg-[#DC2626]'
                  }`}
                  style={{ width: `${observedTubes.length === 0 ? 0 : accuracyPct}%` }}
                />
              </div>
            </div>
          </div>

          {/* Core Stats Breakdown */}
          <div className="grid grid-cols-3 gap-4 text-center">
            <div className="p-3 rounded bg-[#1A1B1E] border border-[#2D2D2D]">
              <span className="text-[10px] text-[#8E9299] uppercase tracking-wider">
                Total Observed
              </span>
              <p className="text-sm font-bold font-mono mt-1 text-[#E2E2E2]">
                {observedTubes.length} tubes
              </p>
            </div>
            <div className="p-3 rounded bg-[#1A1B1E] border border-[#2D2D2D]">
              <span className="text-[10px] text-[#8E9299] uppercase tracking-wider">
                Exceptions
              </span>
              <p className="text-sm font-bold font-mono mt-1 text-[#DC2626]">
                {exceptionCount}
              </p>
            </div>
            <div className="p-3 rounded bg-[#1A1B1E] border border-[#2D2D2D] flex flex-col justify-center items-center">
              <span className="text-[10px] text-[#8E9299] uppercase tracking-wider">
                Procedure Time
              </span>
              <p className="text-sm font-bold font-mono text-[#E2E2E2] flex items-center gap-1 mt-1">
                <Clock className="w-3.5 h-3.5 text-[#8E9299]" />
                {runDuration.toFixed(1)}s
              </p>
            </div>
          </div>

          {/* Sequence of Observed Tubes */}
          <div className="space-y-2">
            <h4 className="text-[10px] font-bold uppercase tracking-widest text-[#8E9299]">
              Observed Draw Sequence
            </h4>
            {observedTubes.length === 0 ? (
              <p className="text-xs text-[#8E9299] italic p-4 text-center bg-[#121214] border border-[#2D2D2D] rounded">
                No tubes were observed during this run.
              </p>
            ) : (
              <div className="p-4 rounded bg-[#121214] border border-[#2D2D2D] space-y-3">
                <div className="flex flex-wrap items-center gap-2">
                  {observedTubes.map((tube, index) => (
                    <React.Fragment key={index}>
                      {index > 0 && <span className="text-gray-600 text-sm">→</span>}
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium border ${
                        tube.valid
                          ? 'bg-emerald-950/20 border-emerald-800/30 text-emerald-300'
                          : 'bg-[#DC2626]/5 border-[#DC2626]/20 text-[#DC2626]'
                      }`}>
                        <span className="w-2 h-2 rounded-full" style={{
                          backgroundColor:
                            tube.cap_color === 'blood_culture' ? '#d97706' :
                            tube.cap_color === 'light_blue' ? '#38bdf8' :
                            tube.cap_color === 'red' ? '#ef4444' :
                            tube.cap_color === 'gold' ? '#f59e0b' :
                            tube.cap_color === 'green' ? '#10b981' :
                            tube.cap_color === 'lavender' ? '#a855f7' :
                            tube.cap_color === 'gray' ? '#6b7280' : '#1e293b'
                        }} />
                        {getFriendlyName(tube.cap_color)}
                      </span>
                    </React.Fragment>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Exceptions & Violations List */}
          <div className="space-y-2">
            <h4 className="text-[10px] font-bold uppercase tracking-widest text-[#DC2626]">
              Clinical Exceptions Detected ({violations.length})
            </h4>
            {violations.length === 0 ? (
              <p className="text-xs text-emerald-400 bg-emerald-950/10 border border-emerald-900/20 p-4 rounded">
                Compliant Run. No protocol exceptions were raised.
              </p>
            ) : (
              <div className="space-y-3">
                {violations.map((violation, index) => (
                  <div
                    key={index}
                    className="p-4 rounded bg-[#DC2626]/5 border border-[#DC2626]/20 space-y-2 text-sm"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-[#DC2626] uppercase text-xs flex items-center gap-1.5">
                        <AlertTriangle className="w-4 h-4" />
                        {violation.type === 'tourniquet' ? 'Tourniquet Overuse' : 'Order of Draw Violation'}
                      </span>
                      <span className="text-xs text-[#8E9299] font-mono">
                        Time: {violation.timestamp.toFixed(1)}s
                      </span>
                    </div>

                    <p className="text-gray-300 text-xs leading-relaxed">{violation.consequence}</p>

                    <div className="flex items-center gap-1 text-[10px] text-[#8E9299] font-sans font-semibold uppercase tracking-wider">
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>{violation.citation}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#121214] border-t border-[#2D2D2D] flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#2D2D2D] hover:bg-[#3D3D3D] border border-[#3D3D3D] rounded text-xs font-bold text-[#E2E2E2] uppercase tracking-widest transition-all"
          >
            Review Session Details
          </button>
          <button
            onClick={onRestart}
            className="px-4 py-2 bg-[#0891B2] hover:bg-[#06B6D4] text-xs font-bold text-white rounded flex items-center gap-1.5 shadow-lg uppercase tracking-widest transition-all font-sans"
          >
            <RefreshCw className="w-4 h-4" />
            Start Another Run
          </button>
        </div>
      </div>
    </div>
  );
}
