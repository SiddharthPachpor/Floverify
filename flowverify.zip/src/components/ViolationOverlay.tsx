/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AlertOctagon, X, Volume2, VolumeX, BookOpen } from 'lucide-react';
import { Violation } from '../types';

interface ViolationOverlayProps {
  violation: Violation | null;
  onDismiss: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export default function ViolationOverlay({
  violation,
  onDismiss,
  isMuted,
  onToggleMute,
}: ViolationOverlayProps) {
  if (!violation) return null;

  return (
    <div className="absolute bottom-4 left-4 right-4 bg-[#1C0D0F]/95 border border-[#DC2626]/40 rounded p-4 shadow-2xl flex items-start gap-3 text-[#E2E2E2] z-20 backdrop-blur-md animate-slide-up">
      {/* Alert Icon */}
      <div className="p-2 rounded bg-[#DC2626]/5 border border-[#DC2626]/20 text-[#DC2626] mt-1 flex-shrink-0 animate-pulse">
        <AlertOctagon className="w-5 h-5" />
      </div>

      {/* Main text info */}
      <div className="flex-1 space-y-1">
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-bold uppercase tracking-widest text-[#DC2626] bg-[#DC2626]/10 px-2 py-0.5 rounded border border-[#DC2626]/20 font-sans">
            PROTOCOL EXCEPTION • {violation.timestamp.toFixed(1)}s
          </span>
          <span className="text-xs text-gray-400">|</span>
          <span className="text-xs text-[#8E9299] italic font-mono flex items-center gap-1">
            <BookOpen className="w-3 h-3 text-[#8E9299]" />
            {violation.citation}
          </span>
        </div>

        <h4 className="text-sm font-bold text-rose-300 leading-snug">
          {violation.type === 'tourniquet'
            ? 'Tourniquet Application Overtime (60s)'
            : 'Out-Of-Order Blood Tube Draw'}
        </h4>

        <p className="text-xs text-[#8E9299] leading-relaxed font-sans">{violation.consequence}</p>
      </div>

      {/* Controls & Dismiss */}
      <div className="flex items-center gap-2 flex-shrink-0">
        <button
          onClick={onToggleMute}
          title={isMuted ? 'Enable spoken warnings' : 'Disable spoken warnings'}
          className="p-1.5 rounded hover:bg-white/5 text-[#8E9299] hover:text-[#E2E2E2] transition-colors"
        >
          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-[#06B6D4]" />}
        </button>
        <button
          onClick={onDismiss}
          className="p-1.5 rounded hover:bg-white/5 text-[#8E9299] hover:text-[#DC2626] transition-colors border border-[#DC2626]/10"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
