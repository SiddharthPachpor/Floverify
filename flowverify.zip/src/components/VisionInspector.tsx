/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Cpu, Film, Info, DollarSign, ToggleLeft, ToggleRight, Calendar } from 'lucide-react';
import { AnalysisFrame } from '../types';

interface VisionInspectorProps {
  history: AnalysisFrame[];
}

export default function VisionInspector({ history }: VisionInspectorProps) {
  const [followLatest, setFollowLatest] = useState(true);
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);

  // Cost Configuration
  const [inputCostPerMillion, setInputCostPerMillion] = useState(0.075); // $0.075 per 1M tokens
  const [outputCostPerMillion, setOutputCostPerMillion] = useState(0.30); // $0.30 per 1M tokens

  // Automatically select latest frame if followLatest is on
  useEffect(() => {
    if (followLatest && history.length > 0) {
      setSelectedIndex(history.length - 1);
    }
  }, [followLatest, history]);

  const activeFrame: AnalysisFrame | undefined =
    selectedIndex !== null && history[selectedIndex] ? history[selectedIndex] : history[history.length - 1];

  // Calculate cost
  let estimatedCost = 0;
  if (activeFrame?.rawDetection?._meta?.usageMetadata) {
    const promptTokens = activeFrame.rawDetection._meta.usageMetadata.promptTokens || 0;
    const candidatesTokens = activeFrame.rawDetection._meta.usageMetadata.candidatesTokens || 0;
    estimatedCost =
      (promptTokens * (inputCostPerMillion / 1000000)) +
      (candidatesTokens * (outputCostPerMillion / 1000000));
  }

  // Last 12 frames for the filmstrip
  const filmstripFrames = history.slice(-12);

  return (
    <div className="bg-[#121214] border border-[#2D2D2D] rounded p-5 text-[#E2E2E2] space-y-5 flex flex-col h-full overflow-y-auto">
      {/* Top Banner */}
      <div className="flex items-center justify-between border-b border-[#2D2D2D] pb-3">
        <div className="flex items-center gap-2">
          <Cpu className="w-5 h-5 text-[#06B6D4]" />
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-[#E2E2E2]">
              Vision Inspector Diagnostic Panel
            </h3>
            <p className="text-[10px] text-[#8E9299] font-mono mt-0.5 uppercase tracking-wider">
              In-memory session stream • {history.length} frames captured
            </p>
          </div>
        </div>

        {/* Follow Latest Toggle */}
        <button
          onClick={() => setFollowLatest(!followLatest)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#2D2D2D] hover:bg-[#3D3D3D] text-[10px] font-semibold text-[#E2E2E2] transition-colors border border-[#3D3D3D] uppercase tracking-widest"
        >
          {followLatest ? (
            <ToggleRight className="w-5 h-5 text-[#06B6D4]" />
          ) : (
            <ToggleLeft className="w-5 h-5 text-[#8E9299]" />
          )}
          <span>Follow Latest</span>
        </button>
      </div>

      {history.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center text-center p-8 border border-dashed border-[#2D2D2D] rounded space-y-2">
          <Film className="w-10 h-10 text-[#8E9299]" />
          <p className="text-xs font-semibold text-[#E2E2E2] uppercase tracking-wider">No telemetry data recorded.</p>
          <p className="text-xs text-[#8E9299] max-w-sm leading-relaxed">
            Upload a video file and start playing or run Replay Mode to begin streaming Gemini Vision metadata.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
          {/* Left Column: Visual JPEGs */}
          <div className="xl:col-span-1 space-y-4">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-[#8E9299]">Current Frame JPEG</span>
              <div className="mt-1 aspect-video rounded border border-[#2D2D2D] bg-black overflow-hidden relative">
                {activeFrame?.image ? (
                  <img
                    src={activeFrame.image}
                    alt="Active Frame"
                    className="w-full h-full object-contain"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-xs text-gray-600 font-mono">
                    Empty Canvas Frame
                  </div>
                )}
                <div className="absolute bottom-1 right-1 px-1.5 py-0.5 rounded bg-black/70 text-[9px] text-[#8E9299] font-mono border border-white/5">
                  t = {activeFrame?.timestamp.toFixed(1)}s
                </div>
              </div>
            </div>

            {/* Previous Frame (Context) */}
            <div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-[#8E9299]">Previous context JPEG</span>
              <div className="mt-1 aspect-video rounded border border-[#2D2D2D] bg-black overflow-hidden relative">
                {selectedIndex !== null && selectedIndex > 0 && history[selectedIndex - 1]?.image ? (
                  <img
                    src={history[selectedIndex - 1].image}
                    alt="Previous Frame"
                    className="w-full h-full object-contain opacity-70"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-xs text-gray-600 font-mono bg-[#0d0d0f]">
                    No Preceding Frame Context
                  </div>
                )}
                <div className="absolute bottom-1 right-1 px-1.5 py-0.5 rounded bg-black/70 text-[9px] text-[#8E9299] font-mono border border-white/5">
                  t = {selectedIndex !== null && selectedIndex > 0 ? history[selectedIndex - 1].timestamp.toFixed(1) : '--'}s
                </div>
              </div>
            </div>
          </div>

          {/* Center Column: Structured JSON & Inference Parameters */}
          <div className="xl:col-span-1 space-y-4">
            <div className="space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-widest text-[#06B6D4]">Gemini Response Payload</span>
              <pre className="p-4 rounded bg-[#121214] border border-[#2D2D2D] font-mono text-[11px] text-emerald-400 overflow-auto h-[265px] leading-normal select-all">
                {activeFrame?.rawDetection
                  ? JSON.stringify(activeFrame.rawDetection, null, 2)
                  : '// Loading payload...'}
              </pre>
            </div>

            {/* Debounce agreement indicators */}
            <div className="p-3 bg-[#1A1B1E] border border-[#2D2D2D] rounded space-y-2 text-xs font-mono text-[#E2E2E2]">
              <div className="flex justify-between items-center pb-1.5 border-b border-[#2D2D2D]">
                <span className="text-[#8E9299] text-[10px] uppercase font-bold tracking-wider">Visual Debounce Decision</span>
                <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                  activeFrame?.accepted
                    ? 'bg-emerald-950/20 text-emerald-400 border border-emerald-900/40'
                    : 'bg-[#2D2D2D] text-[#8E9299]'
                }`}>
                  {activeFrame?.accepted ? 'EVENT ACCEPTED' : 'FILTERED / NO CHG'}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-[10px]">
                <div>
                  <span className="text-[#8E9299]">Unfiltered Event:</span>
                  <p className="text-gray-300 font-semibold">{activeFrame?.rawDetection?.event || 'none'}</p>
                </div>
                <div>
                  <span className="text-[#8E9299]">Unfiltered Cap:</span>
                  <p className="text-gray-300 font-semibold">{activeFrame?.rawDetection?.cap_color || 'none'}</p>
                </div>
                <div>
                  <span className="text-[#8E9299]">Tube Seated:</span>
                  <p className="text-gray-300 font-semibold">{activeFrame?.rawDetection?.tube_seated_in_holder ? 'TRUE' : 'FALSE'}</p>
                </div>
                <div>
                  <span className="text-[#8E9299]">Confidence Score:</span>
                  <p className="text-gray-300 font-semibold">{activeFrame?.rawDetection?.confidence ?? 0}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: API Diagnostics & Token Calculator */}
          <div className="xl:col-span-1 space-y-4">
            <div className="p-4 bg-[#1A1B1E] border border-[#2D2D2D] rounded space-y-3">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-[#E2E2E2] uppercase tracking-widest pb-2 border-b border-[#2D2D2D]">
                <Info className="w-4 h-4 text-[#06B6D4]" />
                <span>API Diagnostic Spec</span>
              </div>

              <div className="space-y-2 text-xs font-mono">
                <div className="flex justify-between">
                  <span className="text-[#8E9299]">Request ID:</span>
                  <span className="text-gray-300 truncate max-w-[150px]" title={activeFrame?.rawDetection?._meta?.requestId}>
                    {activeFrame?.rawDetection?._meta?.requestId || 'detect-fallback'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8E9299]">Active Model:</span>
                  <span className="text-gray-300">{activeFrame?.rawDetection?._meta?.model || 'gemini-3.5-flash'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8E9299]">Latency:</span>
                  <span className="text-emerald-400">{activeFrame?.rawDetection?._meta?.durationMs || 0} ms</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8E9299]">Prompt Tokens:</span>
                  <span className="text-gray-300">{activeFrame?.rawDetection?._meta?.usageMetadata?.promptTokens || 0}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8E9299]">Output Tokens:</span>
                  <span className="text-gray-300">{activeFrame?.rawDetection?._meta?.usageMetadata?.candidatesTokens || 0}</span>
                </div>
              </div>
            </div>

            {/* Estimated Pricing Configurator */}
            <div className="p-4 bg-[#1A1B1E] border border-[#2D2D2D] rounded space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-[#2D2D2D]">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-[#E2E2E2] uppercase tracking-widest">
                  <DollarSign className="w-4 h-4 text-[#06B6D4]" />
                  <span>Cost Configurator</span>
                </div>
                <span className="text-[9px] text-[#8E9299] uppercase font-mono">Estimated cost per call</span>
              </div>

              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="text-[10px] text-[#8E9299] uppercase font-bold tracking-wider">Input Rate (1M)</label>
                    <input
                      type="number"
                      step="0.005"
                      min="0"
                      value={inputCostPerMillion}
                      onChange={(e) => setInputCostPerMillion(parseFloat(e.target.value) || 0)}
                      className="w-full mt-1 px-2 py-1 rounded bg-[#121214] border border-[#2D2D2D] text-[#06B6D4] font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-[#8E9299] uppercase font-bold tracking-wider">Output Rate (1M)</label>
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      value={outputCostPerMillion}
                      onChange={(e) => setOutputCostPerMillion(parseFloat(e.target.value) || 0)}
                      className="w-full mt-1 px-2 py-1 rounded bg-[#121214] border border-[#2D2D2D] text-[#06B6D4] font-mono"
                    />
                  </div>
                </div>

                <div className="p-3 bg-[#0891B2]/5 border border-[#0891B2]/20 rounded flex justify-between items-center">
                  <span className="text-xs text-cyan-300 font-semibold">Active frame cost:</span>
                  <span className="text-sm font-bold font-mono text-[#06B6D4]">
                    ${estimatedCost.toFixed(6)}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Ephemeral Notice */}
      <div className="p-3 bg-[#1A1B1E]/80 rounded border border-[#2D2D2D] text-[10px] text-[#8E9299] leading-normal font-sans">
        *Telemetry frames, base64 images, and response history are stored exclusively in local component memory. Moving between screens will preserve the data, but refreshing the page or starting a new browser session will clear the memory logs.
      </div>

      {/* Filmstrip of last 12 frames */}
      {history.length > 0 && (
        <div className="space-y-2 border-t border-[#2D2D2D] pt-4">
          <span className="text-[10px] font-bold uppercase tracking-widest text-[#8E9299] flex items-center gap-1.5">
            <Film className="w-3.5 h-3.5" />
            Filmstrip Timeline (Click to inspect any frame)
          </span>

          <div className="flex gap-2.5 overflow-x-auto pb-2 select-none">
            {filmstripFrames.map((frame, index) => {
              const actualHistoryIndex = history.indexOf(frame);
              const isSelected = selectedIndex === actualHistoryIndex;

              return (
                <button
                  key={actualHistoryIndex}
                  onClick={() => {
                    setFollowLatest(false);
                    setSelectedIndex(actualHistoryIndex);
                  }}
                  className={`w-16 h-12 flex-shrink-0 rounded border bg-black overflow-hidden relative group transition-all duration-150 ${
                    isSelected
                      ? 'border-[#0891B2] ring-2 ring-[#0891B2]/20 scale-105'
                      : 'border-[#2D2D2D] hover:border-gray-500'
                  }`}
                >
                  <img
                    src={frame.image}
                    alt={`Thumb ${actualHistoryIndex}`}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-all" />
                  <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-[8px] text-[#8E9299] font-mono text-center">
                    {frame.timestamp.toFixed(0)}s
                  </div>
                  {frame.accepted && (
                    <div className="absolute top-0.5 right-0.5 w-1.5 h-1.5 rounded-full bg-emerald-400 ring-1 ring-black" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
