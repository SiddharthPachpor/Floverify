/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  PhlebotomyEvent,
  CapColor,
  DetectionResult,
  Violation,
  ObservedTube,
  ProtocolArtifact,
} from '../types';

export const WHO_PROTOCOL: ProtocolArtifact = {
  protocol_id: 'who_phlebotomy_order_of_draw',
  source: 'WHO Guidelines on Drawing Blood: Best Practices in Phlebotomy, 2010',
  source_url: 'https://www.who.int/publications/i/item/9789241599221',
  steps: [
    {
      order: 1,
      expect: 'blood_culture',
      rule_type: 'sequence',
      consequence: 'Skipping first risks contaminating culture bottles.',
      citation: 'WHO 2010, order of draw',
    },
    {
      order: 2,
      expect: 'light_blue',
      rule_type: 'sequence',
      consequence: 'Citrate tube must precede others to keep coagulation ratios valid.',
      citation: 'WHO 2010, order of draw',
    },
    {
      order: 3,
      expect: 'red',
      rule_type: 'sequence',
      consequence: 'Out of order risks additive carryover into serum tubes.',
      citation: 'WHO 2010, order of draw',
    },
    {
      order: 4,
      expect: 'gold',
      rule_type: 'sequence',
      consequence: 'Gel separator tubes drawn late avoid contaminating earlier draws.',
      citation: 'WHO 2010, order of draw',
    },
    {
      order: 5,
      expect: 'green',
      rule_type: 'sequence',
      consequence: 'Heparin before EDTA prevents potassium contamination of the heparin sample.',
      citation: 'WHO 2010, order of draw',
    },
    {
      order: 6,
      expect: 'lavender',
      rule_type: 'sequence',
      consequence: 'EDTA carryover into earlier tubes falsifies potassium and calcium results.',
      citation: 'WHO 2010, order of draw',
    },
    {
      order: 7,
      expect: 'gray',
      rule_type: 'sequence',
      consequence: 'Fluoride oxalate last prevents contaminating other additives.',
      citation: 'WHO 2010, order of draw',
    },
  ],
  timing_rules: [
    {
      rule_type: 'max_duration',
      trigger: 'tourniquet_on',
      reset: 'tourniquet_off',
      limit_seconds: 60,
      consequence: 'Tourniquet over 60 seconds causes hemoconcentration and can skew results.',
      citation: 'WHO 2010, tourniquet application',
    },
  ],
};

const RANK_MAP: Record<CapColor, number> = {
  blood_culture: 1,
  light_blue: 2,
  red: 3,
  gold: 4,
  green: 5,
  lavender: 6,
  gray: 7,
  none: 0,
};

export function getFriendlyName(color: CapColor): string {
  switch (color) {
    case 'blood_culture':
      return 'Blood Culture bottle';
    case 'light_blue':
      return 'Light Blue / Citrate tube';
    case 'red':
      return 'Red / Serum tube';
    case 'gold':
      return 'Gold / SST (gel separator) tube';
    case 'green':
      return 'Green / Heparin tube';
    case 'lavender':
      return 'Lavender / EDTA tube';
    case 'gray':
      return 'Gray / Fluoride Oxalate tube';
    default:
      return 'Unknown';
  }
}

export function getConsequenceForViolation(previous: CapColor, detected: CapColor): string {
  if (previous === 'green' && detected === 'gold') {
    return 'Green / heparin was already drawn. Drawing Gold / SST afterward risks additive carryover and may skew the earlier-order sample.';
  }
  if (previous === 'lavender' && detected === 'green') {
    return 'EDTA (lavender) was already drawn. Drawing Green / heparin afterward risks EDTA carryover which can falsify potassium and calcium results.';
  }
  
  // Dynamic fallback from protocol rules if match is found
  const step = WHO_PROTOCOL.steps.find((s) => s.expect === detected);
  if (step) {
    return `${getFriendlyName(previous)} was already drawn. Drawing ${getFriendlyName(detected)} afterward risks additive carryover. ${step.consequence}`;
  }

  return `${getFriendlyName(previous)} was already drawn. Drawing ${getFriendlyName(detected)} afterward risks additive carryover and violates the WHO phlebotomy order of draw.`;
}

export class ProtocolEngine {
  public lastAcceptedRank = 0;
  public lastAcceptedColor: CapColor | null = null;
  public observedTubes: ObservedTube[] = [];
  public violations: Violation[] = [];
  public tourniquetOnTime: number | null = null;
  public tourniquetViolationRaised = false;

  // Debounce state
  public debouncePrevFrame: { event: PhlebotomyEvent; cap_color: CapColor } | null = null;
  public currentAcceptedEvent: { event: PhlebotomyEvent; cap_color: CapColor } | null = null;

  constructor() {
    this.reset();
  }

  public reset(): void {
    this.lastAcceptedRank = 0;
    this.lastAcceptedColor = null;
    this.observedTubes = [];
    this.violations = [];
    this.tourniquetOnTime = null;
    this.tourniquetViolationRaised = false;
    this.debouncePrevFrame = null;
    this.currentAcceptedEvent = null;
  }

  /**
   * Processes a single detection frame.
   * Returns whether a new event was accepted on this frame.
   */
  public processFrame(detection: DetectionResult, timestamp: number): {
    acceptedEvent: { event: PhlebotomyEvent; cap_color: CapColor } | null;
    tourniquetTime: number | null;
  } {
    // 1. Ignore detections below 0.6 confidence
    if (detection.confidence < 0.6) {
      // Keep tracking active tourniquet time even if detection has low confidence
      const tourniquetTime = this.updateTourniquetTimer(timestamp);
      return { acceptedEvent: null, tourniquetTime };
    }

    let currentEvent = detection.event;
    let currentColor = detection.cap_color;

    // Filter tube_inserted based on specific evidence requirements
    if (currentEvent === 'tube_inserted') {
      if (!detection.tube_in_hand || !detection.tube_seated_in_holder || currentColor === 'none') {
        // Ignored or treated as none
        currentEvent = 'none';
        currentColor = 'none';
      }
    }

    let acceptedThisFrame: { event: PhlebotomyEvent; cap_color: CapColor } | null = null;

    // 2. Debounce logic (two consecutive matching frames)
    if (
      this.debouncePrevFrame &&
      this.debouncePrevFrame.event === currentEvent &&
      this.debouncePrevFrame.cap_color === currentColor
    ) {
      // Two consecutive matching confident frames!
      const isNew =
        !this.currentAcceptedEvent ||
        this.currentAcceptedEvent.event !== currentEvent ||
        this.currentAcceptedEvent.cap_color !== currentColor;

      if (isNew) {
        // Accept the event
        this.currentAcceptedEvent = { event: currentEvent, cap_color: currentColor };
        acceptedThisFrame = this.currentAcceptedEvent;

        // Apply event to protocol engine
        this.handleAcceptedEvent(currentEvent, currentColor, timestamp);
      }
    } else {
      // Stash this frame as previous for next comparison
      this.debouncePrevFrame = { event: currentEvent, cap_color: currentColor };
    }

    // 3. Reset accepted detection after a confident none event
    if (currentEvent === 'none') {
      this.currentAcceptedEvent = null;
    }

    // 4. Update tourniquet timer & rules
    const tourniquetTime = this.updateTourniquetTimer(timestamp);

    return { acceptedEvent: acceptedThisFrame, tourniquetTime };
  }

  private handleAcceptedEvent(event: PhlebotomyEvent, color: CapColor, timestamp: number): void {
    if (event === 'tourniquet_on') {
      this.tourniquetOnTime = timestamp;
      this.tourniquetViolationRaised = false;
    } else if (event === 'tourniquet_off') {
      this.tourniquetOnTime = null;
    } else if (event === 'tube_inserted') {
      const rank = RANK_MAP[color] || 0;
      if (rank === 0) return;

      const isValid = rank >= this.lastAcceptedRank;

      if (isValid) {
        this.lastAcceptedRank = rank;
        this.lastAcceptedColor = color;
        this.observedTubes.push({ cap_color: color, timestamp, valid: true });
      } else {
        // Out of order sequence violation!
        const citation = 'WHO 2010, order of draw';
        const consequence = getConsequenceForViolation(this.lastAcceptedColor || 'none', color);

        this.violations.push({
          type: 'sequence',
          timestamp,
          detected: color,
          previous: this.lastAcceptedColor || undefined,
          consequence,
          citation,
        });

        this.observedTubes.push({ cap_color: color, timestamp, valid: false });
      }
    }
  }

  private updateTourniquetTimer(timestamp: number): number | null {
    if (this.tourniquetOnTime === null) return null;

    const elapsed = timestamp - this.tourniquetOnTime;

    if (elapsed > 60 && !this.tourniquetViolationRaised) {
      this.tourniquetViolationRaised = true;
      this.violations.push({
        type: 'tourniquet',
        timestamp,
        consequence: 'Tourniquet over 60 seconds causes hemoconcentration and can skew results.',
        citation: 'WHO 2010, tourniquet application',
      });
    }

    return elapsed;
  }

  /**
   * Generates final score stats.
   */
  public getScorecard(runDuration = 0): {
    accuracy: number;
    completed: number;
    totalChecks: number;
    exceptionCount: number;
    passed: boolean;
    violations: Violation[];
    observedTubes: ObservedTube[];
    runDuration: number;
  } {
    const completed = this.observedTubes.filter((t) => t.valid).length;
    const exceptionCount = this.violations.length;
    const totalChecks = completed + this.violations.filter((v) => v.type === 'sequence').length;

    const accuracy = totalChecks > 0 ? completed / totalChecks : 0;
    // Pass when at least one draw was verified and there are zero violations
    const passed = completed > 0 && exceptionCount === 0;

    return {
      accuracy,
      completed,
      totalChecks,
      exceptionCount,
      passed,
      violations: this.violations,
      observedTubes: this.observedTubes,
      runDuration,
    };
  }
}
