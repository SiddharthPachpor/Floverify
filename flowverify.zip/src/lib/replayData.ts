/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { DetectionResponse } from '../types';

// Short synthetic timeline of events mapped to integer video timestamps (seconds)
// Allows testing the whole flow in the preview without making actual Gemini API calls
export const REPLAY_TIMELINE_MAP: Record<number, Omit<DetectionResponse, '_meta'> & { _meta: any }> = {
  // At 0s, 1s, 2s: Tourniquet applied
  1: {
    event: 'tourniquet_on',
    cap_color: 'none',
    tube_in_hand: false,
    tube_seated_in_holder: false,
    confidence: 0.95,
    _meta: { requestId: 'rep-tourn-1', model: 'replay-cached', durationMs: 120, finishReason: 'STOP', thinkingLevel: 'minimal' }
  },
  2: {
    event: 'tourniquet_on',
    cap_color: 'none',
    tube_in_hand: false,
    tube_seated_in_holder: false,
    confidence: 0.96,
    _meta: { requestId: 'rep-tourn-2', model: 'replay-cached', durationMs: 110, finishReason: 'STOP', thinkingLevel: 'minimal' }
  },
  // At 5s, 6s: Blood culture bottle inserted
  5: {
    event: 'tube_inserted',
    cap_color: 'blood_culture',
    tube_in_hand: true,
    tube_seated_in_holder: true,
    confidence: 0.94,
    _meta: { requestId: 'rep-bc-1', model: 'replay-cached', durationMs: 140, finishReason: 'STOP', thinkingLevel: 'minimal' }
  },
  6: {
    event: 'tube_inserted',
    cap_color: 'blood_culture',
    tube_in_hand: true,
    tube_seated_in_holder: true,
    confidence: 0.97,
    _meta: { requestId: 'rep-bc-2', model: 'replay-cached', durationMs: 130, finishReason: 'STOP', thinkingLevel: 'minimal' }
  },
  // At 9s, 10s: Light blue tube inserted
  9: {
    event: 'tube_inserted',
    cap_color: 'light_blue',
    tube_in_hand: true,
    tube_seated_in_holder: true,
    confidence: 0.95,
    _meta: { requestId: 'rep-lb-1', model: 'replay-cached', durationMs: 150, finishReason: 'STOP', thinkingLevel: 'minimal' }
  },
  10: {
    event: 'tube_inserted',
    cap_color: 'light_blue',
    tube_in_hand: true,
    tube_seated_in_holder: true,
    confidence: 0.98,
    _meta: { requestId: 'rep-lb-2', model: 'replay-cached', durationMs: 120, finishReason: 'STOP', thinkingLevel: 'minimal' }
  },
  // At 13s, 14s: Red tube inserted
  13: {
    event: 'tube_inserted',
    cap_color: 'red',
    tube_in_hand: true,
    tube_seated_in_holder: true,
    confidence: 0.93,
    _meta: { requestId: 'rep-red-1', model: 'replay-cached', durationMs: 130, finishReason: 'STOP', thinkingLevel: 'minimal' }
  },
  14: {
    event: 'tube_inserted',
    cap_color: 'red',
    tube_in_hand: true,
    tube_seated_in_holder: true,
    confidence: 0.96,
    _meta: { requestId: 'rep-red-2', model: 'replay-cached', durationMs: 140, finishReason: 'STOP', thinkingLevel: 'minimal' }
  },
  // At 17s, 18s: Green tube inserted (skipping Gold)
  17: {
    event: 'tube_inserted',
    cap_color: 'green',
    tube_in_hand: true,
    tube_seated_in_holder: true,
    confidence: 0.92,
    _meta: { requestId: 'rep-green-1', model: 'replay-cached', durationMs: 160, finishReason: 'STOP', thinkingLevel: 'minimal' }
  },
  18: {
    event: 'tube_inserted',
    cap_color: 'green',
    tube_in_hand: true,
    tube_seated_in_holder: true,
    confidence: 0.95,
    _meta: { requestId: 'rep-green-2', model: 'replay-cached', durationMs: 150, finishReason: 'STOP', thinkingLevel: 'minimal' }
  },
  // At 21s, 22s: Gold tube inserted (Backward order violation!)
  21: {
    event: 'tube_inserted',
    cap_color: 'gold',
    tube_in_hand: true,
    tube_seated_in_holder: true,
    confidence: 0.91,
    _meta: { requestId: 'rep-gold-1', model: 'replay-cached', durationMs: 140, finishReason: 'STOP', thinkingLevel: 'minimal' }
  },
  22: {
    event: 'tube_inserted',
    cap_color: 'gold',
    tube_in_hand: true,
    tube_seated_in_holder: true,
    confidence: 0.94,
    _meta: { requestId: 'rep-gold-2', model: 'replay-cached', durationMs: 130, finishReason: 'STOP', thinkingLevel: 'minimal' }
  },
  // At 25s, 26s: Green again
  25: {
    event: 'tube_inserted',
    cap_color: 'green',
    tube_in_hand: true,
    tube_seated_in_holder: true,
    confidence: 0.95,
    _meta: { requestId: 'rep-green-3', model: 'replay-cached', durationMs: 120, finishReason: 'STOP', thinkingLevel: 'minimal' }
  },
  26: {
    event: 'tube_inserted',
    cap_color: 'green',
    tube_in_hand: true,
    tube_seated_in_holder: true,
    confidence: 0.97,
    _meta: { requestId: 'rep-green-4', model: 'replay-cached', durationMs: 130, finishReason: 'STOP', thinkingLevel: 'minimal' }
  },
  // At 29s, 30s: Lavender tube inserted
  29: {
    event: 'tube_inserted',
    cap_color: 'lavender',
    tube_in_hand: true,
    tube_seated_in_holder: true,
    confidence: 0.93,
    _meta: { requestId: 'rep-lav-1', model: 'replay-cached', durationMs: 150, finishReason: 'STOP', thinkingLevel: 'minimal' }
  },
  30: {
    event: 'tube_inserted',
    cap_color: 'lavender',
    tube_in_hand: true,
    tube_seated_in_holder: true,
    confidence: 0.96,
    _meta: { requestId: 'rep-lav-2', model: 'replay-cached', durationMs: 140, finishReason: 'STOP', thinkingLevel: 'minimal' }
  },
  // At 33s, 34s: Gray tube inserted
  33: {
    event: 'tube_inserted',
    cap_color: 'gray',
    tube_in_hand: true,
    tube_seated_in_holder: true,
    confidence: 0.94,
    _meta: { requestId: 'rep-gray-1', model: 'replay-cached', durationMs: 130, finishReason: 'STOP', thinkingLevel: 'minimal' }
  },
  34: {
    event: 'tube_inserted',
    cap_color: 'gray',
    tube_in_hand: true,
    tube_seated_in_holder: true,
    confidence: 0.97,
    _meta: { requestId: 'rep-gray-2', model: 'replay-cached', durationMs: 120, finishReason: 'STOP', thinkingLevel: 'minimal' }
  },
  // At 37s, 38s: Tourniquet released
  37: {
    event: 'tourniquet_off',
    cap_color: 'none',
    tube_in_hand: false,
    tube_seated_in_holder: false,
    confidence: 0.95,
    _meta: { requestId: 'rep-toff-1', model: 'replay-cached', durationMs: 110, finishReason: 'STOP', thinkingLevel: 'minimal' }
  },
  38: {
    event: 'tourniquet_off',
    cap_color: 'none',
    tube_in_hand: false,
    tube_seated_in_holder: false,
    confidence: 0.98,
    _meta: { requestId: 'rep-toff-2', model: 'replay-cached', durationMs: 100, finishReason: 'STOP', thinkingLevel: 'minimal' }
  }
};

// Return a mock response for a given second, or a confident 'none' frame to represent regular gameplay
export function getMockDetectionAtTime(timeSeconds: number): DetectionResponse {
  const integerSec = Math.floor(timeSeconds);
  if (REPLAY_TIMELINE_MAP[integerSec]) {
    return REPLAY_TIMELINE_MAP[integerSec];
  }
  // Otherwise, default confident none frame
  return {
    event: 'none',
    cap_color: 'none',
    tube_in_hand: false,
    tube_seated_in_holder: false,
    confidence: 0.95,
    _meta: {
      requestId: `rep-none-${integerSec}`,
      model: 'replay-cached',
      durationMs: 40,
      finishReason: 'STOP',
      thinkingLevel: 'minimal',
      usageMetadata: {
        promptTokens: 210,
        candidatesTokens: 12,
        totalTokens: 222
      }
    }
  };
}
