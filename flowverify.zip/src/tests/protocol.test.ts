/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { test, describe } from 'node:test';
import assert from 'node:assert';
import { ProtocolEngine } from '../lib/protocolEngine';
import { DetectionResult } from '../types';

describe('FlowVerify Protocol Engine Tests', () => {
  // Helpers to simulate frames
  const createFrame = (
    event: any,
    cap_color: any,
    confidence = 0.9,
    in_hand = true,
    seated = true
  ): DetectionResult => ({
    event,
    cap_color,
    confidence,
    tube_in_hand: in_hand,
    tube_seated_in_holder: seated,
  });

  test('1. A complete correct sequence passes', () => {
    const engine = new ProtocolEngine();
    const sequence = [
      'blood_culture',
      'light_blue',
      'red',
      'gold',
      'green',
      'lavender',
      'gray',
    ] as const;

    let time = 1.0;
    for (const color of sequence) {
      const frame = createFrame('tube_inserted', color);
      // Process twice for debounce
      engine.processFrame(frame, time);
      engine.processFrame(frame, time + 1.0);
      time += 2.0;
    }

    const scorecard = engine.getScorecard(time);
    assert.strictEqual(scorecard.exceptionCount, 0);
    assert.strictEqual(scorecard.completed, 7);
    assert.strictEqual(scorecard.passed, true);
  });

  test('2. A partial green -> lavender -> gray sequence passes', () => {
    const engine = new ProtocolEngine();
    const sequence = ['green', 'lavender', 'gray'] as const;

    let time = 1.0;
    for (const color of sequence) {
      const frame = createFrame('tube_inserted', color);
      engine.processFrame(frame, time);
      engine.processFrame(frame, time + 0.5);
      time += 1.0;
    }

    const scorecard = engine.getScorecard(time);
    assert.strictEqual(scorecard.exceptionCount, 0);
    assert.strictEqual(scorecard.completed, 3);
    assert.strictEqual(scorecard.passed, true);
  });

  test('3. A two-tube red -> green sequence passes', () => {
    const engine = new ProtocolEngine();
    const sequence = ['red', 'green'] as const;

    let time = 1.0;
    for (const color of sequence) {
      const frame = createFrame('tube_inserted', color);
      engine.processFrame(frame, time);
      engine.processFrame(frame, time + 0.5);
      time += 1.0;
    }

    const scorecard = engine.getScorecard(time);
    assert.strictEqual(scorecard.exceptionCount, 0);
    assert.strictEqual(scorecard.completed, 2);
    assert.strictEqual(scorecard.passed, true);
  });

  test('4. Repeated gold -> gold is valid', () => {
    const engine = new ProtocolEngine();
    let time = 1.0;

    // First gold
    const frameGold1 = createFrame('tube_inserted', 'gold');
    engine.processFrame(frameGold1, time);
    engine.processFrame(frameGold1, time + 0.5);
    time += 1.0;

    // Confident none to reset debounce so same tube category can be accepted again
    const frameNone = createFrame('none', 'none');
    engine.processFrame(frameNone, time);
    engine.processFrame(frameNone, time + 0.5);
    time += 1.0;

    // Second gold
    const frameGold2 = createFrame('tube_inserted', 'gold');
    engine.processFrame(frameGold2, time);
    engine.processFrame(frameGold2, time + 0.5);
    time += 1.0;

    const scorecard = engine.getScorecard(time);
    assert.strictEqual(scorecard.exceptionCount, 0);
    assert.strictEqual(scorecard.completed, 2);
    assert.strictEqual(scorecard.passed, true);
  });

  test('5. Lavender -> green creates one cited violation', () => {
    const engine = new ProtocolEngine();
    let time = 1.0;

    // Lavender
    const frameLav = createFrame('tube_inserted', 'lavender');
    engine.processFrame(frameLav, time);
    engine.processFrame(frameLav, time + 0.5);
    time += 1.0;

    // Confident none
    const frameNone = createFrame('none', 'none');
    engine.processFrame(frameNone, time);
    time += 1.0;

    // Green (violation)
    const frameGreen = createFrame('tube_inserted', 'green');
    engine.processFrame(frameGreen, time);
    engine.processFrame(frameGreen, time + 0.5);
    time += 1.0;

    const scorecard = engine.getScorecard(time);
    assert.strictEqual(scorecard.exceptionCount, 1);
    assert.strictEqual(scorecard.violations[0].type, 'sequence');
    assert.strictEqual(scorecard.violations[0].citation, 'WHO 2010, order of draw');
    assert.strictEqual(scorecard.passed, false);
  });

  test('6. A held tube that is not seated is ignored', () => {
    const engine = new ProtocolEngine();
    let time = 1.0;

    // Hand holds it but it is NOT seated (tube_seated_in_holder = false)
    const frameUnseated = createFrame('tube_inserted', 'green', 0.9, true, false);
    engine.processFrame(frameUnseated, time);
    engine.processFrame(frameUnseated, time + 0.5);
    time += 1.0;

    const scorecard = engine.getScorecard(time);
    assert.strictEqual(scorecard.completed, 0);
    assert.strictEqual(scorecard.exceptionCount, 0);
  });

  test('7. Low-confidence detections are ignored', () => {
    const engine = new ProtocolEngine();
    let time = 1.0;

    // Gold with 0.5 confidence (less than 0.6)
    const frameLowConf = createFrame('tube_inserted', 'gold', 0.5, true, true);
    engine.processFrame(frameLowConf, time);
    engine.processFrame(frameLowConf, time + 0.5);
    time += 1.0;

    const scorecard = engine.getScorecard(time);
    assert.strictEqual(scorecard.completed, 0);
  });

  test('8. Debounce accepts only the second matching confident frame', () => {
    const engine = new ProtocolEngine();
    let time = 1.0;

    // Frame 1: Gold
    const goldFrame = createFrame('tube_inserted', 'gold');
    const step1 = engine.processFrame(goldFrame, time);
    assert.strictEqual(step1.acceptedEvent, null); // Not accepted yet

    time += 0.5;
    // Frame 2: Gold again
    const step2 = engine.processFrame(goldFrame, time);
    assert.ok(step2.acceptedEvent); // Accepted now!
    assert.strictEqual(step2.acceptedEvent?.cap_color, 'gold');
  });

  test('9. A tourniquet violation fires once after 60 seconds of video time', () => {
    const engine = new ProtocolEngine();

    // Tourniquet On at 5.0 seconds
    const tournOn = createFrame('tourniquet_on', 'none');
    engine.processFrame(tournOn, 5.0);
    engine.processFrame(tournOn, 5.5);

    // Some intermediate frames up to 70 seconds
    const regularFrame = createFrame('none', 'none');
    engine.processFrame(regularFrame, 20.0);
    engine.processFrame(regularFrame, 40.0);
    engine.processFrame(regularFrame, 70.0); // 70.0 - 5.5 = 64.5s elapsed! Threshold crossed (60s)

    // Ensure violation fired
    assert.strictEqual(engine.violations.length, 1);
    assert.strictEqual(engine.violations[0].type, 'tourniquet');
    assert.strictEqual(engine.violations[0].citation, 'WHO 2010, tourniquet application');

    // Make sure it doesn't fire multiple times
    engine.processFrame(regularFrame, 70.0);
    assert.strictEqual(engine.violations.length, 1);
  });

  test('10. The scorecard passes a partial valid run without requiring all categories', () => {
    const engine = new ProtocolEngine();
    let time = 1.0;

    // Citrate then SST
    const citrate = createFrame('tube_inserted', 'light_blue');
    engine.processFrame(citrate, time);
    engine.processFrame(citrate, time + 0.5);
    time += 1.0;

    // Confident none
    const frameNone = createFrame('none', 'none');
    engine.processFrame(frameNone, time);
    time += 1.0;

    const gold = createFrame('tube_inserted', 'gold');
    engine.processFrame(gold, time);
    engine.processFrame(gold, time + 0.5);
    time += 1.0;

    const scorecard = engine.getScorecard(time);
    assert.strictEqual(scorecard.completed, 2);
    assert.strictEqual(scorecard.exceptionCount, 0);
    assert.strictEqual(scorecard.passed, true); // No violations, some draws completed, so passed is true
  });
});
